import os
import anthropic
import streamlit as st
from dotenv import load_dotenv
from system_prompt import SYSTEM_PROMPT

# Load API key from .env file
load_dotenv()
client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="CrystalInk Technologies AI Assistant",
    page_icon="🌐",
    layout="centered"
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main { background-color: #f0f4f8; }
    .header-box {
        background: linear-gradient(135deg, #1F4E79, #2E75B6);
        color: white;
        padding: 20px 30px;
        border-radius: 12px;
        margin-bottom: 20px;
        text-align: center;
    }
    .header-box h1 { margin: 0; font-size: 1.8em; }
    .header-box p  { margin: 6px 0 0; font-size: 0.95em; opacity: 0.9; }
</style>
""", unsafe_allow_html=True)

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="header-box">
    <h1>🌐 CrystalInk Technologies</h1>
    <p>Connecting your world, one network at a time</p>
    <p style="font-size:0.8em; opacity:0.75;">AI Assistant — Available 24/7</p>
</div>
""", unsafe_allow_html=True)

# ── Session state ─────────────────────────────────────────────────────────────
if "messages" not in st.session_state:
    st.session_state.messages = []
    st.session_state.greeted = False

# ── Greeting on first load ────────────────────────────────────────────────────
if not st.session_state.greeted:
    greeting = (
        "👋 Welcome to CrystalInk Technologies! I'm your AI assistant, here to help "
        "with all your networking, security, AV, and smart technology needs.\n\n"
        "Whether you're a homeowner, business owner, or managing a large facility — "
        "we have solutions for you across the DMV area and beyond.\n\n"
        "**What can I help you with today?** Tell me about your project and I'll give "
        "you a recommendation and estimate!"
    )
    st.session_state.messages.append({"role": "assistant", "content": greeting})
    st.session_state.greeted = True

# ── Quick prompt buttons ──────────────────────────────────────────────────────
st.markdown("**Quick questions:**")
col1, col2, col3, col4 = st.columns(4)
quick_prompts = {
    col1: "💰 Get a quote",
    col2: "📋 Your services",
    col3: "🏢 Large facility",
    col4: "🏠 Homeowner",
}
for col, label in quick_prompts.items():
    with col:
        if st.button(label, use_container_width=True):
            st.session_state.messages.append({"role": "user", "content": label})
            with st.spinner("Thinking..."):
                api_messages = [
                    {"role": m["role"], "content": m["content"]}
                    for m in st.session_state.messages
                    if m["role"] in ["user", "assistant"]
                ]
                response = client.messages.create(
                    model="claude-haiku-4-5-20251001",
                    max_tokens=1024,
                    system=SYSTEM_PROMPT,
                    messages=api_messages
                )
                reply = response.content[0].text
            st.session_state.messages.append({"role": "assistant", "content": reply})
            st.rerun()

st.divider()

# ── Chat history display ──────────────────────────────────────────────────────
for msg in st.session_state.messages:
    with st.chat_message(msg["role"], avatar="🌐" if msg["role"] == "assistant" else "👤"):
        st.markdown(msg["content"])

# ── Chat input ────────────────────────────────────────────────────────────────
if user_input := st.chat_input("Describe your project or ask a question..."):
    st.session_state.messages.append({"role": "user", "content": user_input})

    with st.chat_message("user", avatar="👤"):
        st.markdown(user_input)

    with st.chat_message("assistant", avatar="🌐"):
        with st.spinner("CrystalInk AI is thinking..."):
            api_messages = [
                {"role": m["role"], "content": m["content"]}
                for m in st.session_state.messages
                if m["role"] in ["user", "assistant"]
            ]
            response = client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=1024,
                system=SYSTEM_PROMPT,
                messages=api_messages
            )
            reply = response.content[0].text
        st.markdown(reply)

    st.session_state.messages.append({"role": "assistant", "content": reply})

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🌐 CrystalInk Technologies")
    st.markdown("**📍 DMV Area & Neighboring States**")
    st.markdown("**🌐** [crystalinktechnologies.com](https://crystalinktechnologies.com)")
    st.divider()
    st.markdown("**Our Services:**")
    services = [
        "📡 Network Installation",
        "🔧 Network Upgrades & Repairs",
        "📶 WiFi Infrastructure",
        "📷 Security Cameras / CCTV",
        "🔌 Structured Cabling",
        "🎬 AV Systems",
        "🏠 Smart Home / Automation",
        "💼 IT Consulting",
    ]
    for s in services:
        st.markdown(f"- {s}")
    st.divider()
    st.markdown("**We serve:**")
    st.markdown("Homeowners · Businesses · Hotels · Offices · Schools · Government · Retail")
    st.divider()
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.session_state.greeted = False
        st.rerun()
